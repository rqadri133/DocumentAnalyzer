﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentParserRetrievelService.filer;
using DocumentParserRetrievelService.Parsers;
namespace DocumentAnalyzer
{
    class Program
    {
        static void Main(string[] args)
        {
            DocumentAnalyzerEntities context = new DocumentAnalyzerEntities();
            DocTemplate template = context.DocTemplates.ToList()[0];
            string caseType = template.TYPE;
            IDocumentParser parser = null;
            switch (caseType)
            {
                case "TEXT":
                    parser = new TextDocument();
                    break;
                case "WORD":
                    parser = new WordDocument();
                    break;
            }
            List<AccountInformation> accounts = parser.ParseDocument(template);
            foreach(AccountInformation account in accounts)
            {
                Console.Write("Account Number:" + account.AccountNumber + Environment.NewLine);
                Console.Write("Page Number:" + account.PageNumber + Environment.NewLine);
                Console.WriteLine("Address:" + account.Address);
            }
            Console.ReadLine();
        }
    }
}
