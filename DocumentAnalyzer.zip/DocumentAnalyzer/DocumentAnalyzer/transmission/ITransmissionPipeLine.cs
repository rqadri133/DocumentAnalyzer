﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DocumentParserRetrievelService;
using System.Threading;
using System.Threading.Tasks;
using DocumentAnalyzer;
namespace DocumentParserRetrievelService.transmission
{
    interface ITransmissionPipeLine
    {
        // What time you want to start transmission by default pass now or 
         TransmissionHistory RecordTransmission( Document document);
    }


    public class  SimpleTransmision : ITransmissionPipeLine
    {
        public TransmissionHistory RecordTransmission(Document document)
        {




            return new TransmissionHistory(); 

        }

     

    } 


    


}