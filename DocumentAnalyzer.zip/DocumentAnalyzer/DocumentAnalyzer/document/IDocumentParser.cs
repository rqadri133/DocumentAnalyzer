﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentAnalyzer;
using DocumentParserRetrievelService.filer;

namespace DocumentParserRetrievelService.Parsers
{
    interface IDocumentParser
    {
        // int PasrseDocument<T>(T document);
        List<AccountInformation> ParseDocument(DocTemplate document);
    }


   
    // int PasrseDocument<T>(T document);

}
