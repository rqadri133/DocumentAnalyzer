﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DocumentParserRetrievelService;
using DocumentAnalyzer;
using DocumentParserRetrievelService.filer;

namespace DocumentParserRetrievelService.Parsers
{
    public class WordDocument : IDocumentParser
    {
        List<AccountInformation> IDocumentParser.ParseDocument(DocTemplate document)
        {
            return new List<AccountInformation>();
        }
    }

    public class PDFDocument : IDocumentParser
    {
        List<AccountInformation> IDocumentParser.ParseDocument(DocTemplate document)
        {
            return new List<AccountInformation>();
        }
    }


    public class TextDocument : IDocumentParser
    {
        List<AccountInformation> IDocumentParser.ParseDocument(DocTemplate document)
        {
            ISingleFileLogicController fileController = new FileContentVericlePlain();
            List<AccountInformation> accounts =  fileController.ReadFile(document);
            // implmentation required 

            return accounts;
            
        }
    }




}