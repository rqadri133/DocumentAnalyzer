using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using DocumentParserRetrievelService;
using DocumentAnalyzer;
using System.Configuration.Assemblies;
using System.Configuration;


namespace DocumentParserRetrievelService.filer
{
   interface ISingleFileLogicController
    {
        // file parallel , horizontal , verticle Document read content 

       List<AccountInformation> ReadFile(DocTemplate documment);
      
    }

    // users who will desire fast reads
    interface IMultiFileLogicController

    {
        List<AccountInformation> ReadFile(List<DocTemplate> documment);

    }


  public class TableData
  {
     public List<ColumnData> Columns { get; set; }
     public string TableTitle { get; set; }


  }

  public class ColumnData
  {
    public int ColumnIndex
    {
      get;
      set;
    }
    public string ColumnName
    {
      get;
      set;
    }

    public string ColumnValue
    {
      get;
      set;
    }

  }

  public class DataIndexerPoint
    {
        public int StartIndex
        {
            get;
            set;

        }

        public int EndIndex
        {
            get;set;

        }

    }

    public class LineContent
    {
        public int ContentID
        {
            get;
            set;
            
        }

     

       public string ContentValue
       {
          get;set;

       }

    public string MarkStartToken
    {

      get;
      set;
    }

    public string MarkEndToken
    {
      get;
        set; 

    }
  


  }

    public class AccountInformation
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string AccountNumber { get; set; }
        public string PageNumber { get; set; }
        public string BankName { get; set; }
      
    }

    public class AccountLedger
    {
          public string Description { get; set; }
          public decimal DEBITS { get; set; }
          public decimal CREDITS { get; set; }
          public string Date { get; set; }
          public decimal Balance { get; set; }
        

    }

  public class FileContentVericlePlain : ISingleFileLogicController
    {
        List<LineContent> allContent = new List<LineContent>();
         #region "get indexers"
        private List<DataIndexerPoint> GetIndexers(List<LineContent> headerTable , DocTemplate doc , List<LineContent> allContent)
        {
            DataIndexerPoint indexPointer = null; 
            List<LineContent> bFotterMarker  =  allContent.FindAll(p=> p.ContentValue.Contains(doc.DocTemplateEndToken));
            List<DataIndexerPoint> indexers = new List<DataIndexerPoint>();
            foreach (LineContent headDesc in headerTable)
            {
               
                foreach(LineContent footMarker in bFotterMarker)
                {
                    indexPointer = new DataIndexerPoint();
                    // always 2 index down
                  
                    indexPointer.StartIndex = headDesc.ContentID + Convert.ToInt32( ConfigurationManager.AppSettings["DataStartDownIndex"]);
                    indexPointer.EndIndex = footMarker.ContentID - Convert.ToInt32(ConfigurationManager.AppSettings["DataEndUpIndex"]);
                    bFotterMarker.Remove(footMarker);
                    indexers.Add(indexPointer);
                   
                    break;
                   
                }


            }
            return indexers;

        }
         #endregion



        #region "send header index and get data from memory"

        private List<AccountInformation> LoadLedgerAccountHeaderInformation(List<LineContent> allcontent , DocTemplate doc )
        {
            // get all indexers of 
            List<LineContent> headers = new List<LineContent>();
            List<LineContent> datas = new List<LineContent>();
            // PAGE Line Spilit
            //  DESCRIPTION            DEBITS        CREDITS   DATE           BALANCE
            // Since its a flat file all the settings coming from DB

            // GO DOWN 0 1 (2 indexers)
            // Find the 
            List<string> pageline = new List<string>();
            List<string> cominedIndexer = new List<string>();
            
            headers   = allContent.FindAll(p => p.ContentValue.Contains(doc.PAGE));
            // here the document setting allow us to read content data for table
            datas = allContent.FindAll(p => p.ContentValue.Contains(doc.HeaderColumnsTable));

            AccountInformation account = new AccountInformation();
            List<AccountInformation> accounts = new List<AccountInformation>();
            LineContent _jumpToNext = null;
            foreach(LineContent header in headers)
            {
                pageline =   header.ContentValue.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).ToList();
                account = new AccountInformation();
                account.PageNumber = pageline[doc.PageLineIndex];
                // account.BankName = pageline[doc.BankNameLineXIndex];
                cominedIndexer = doc.BankNameLineXIndex.Split("@".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).ToList();
                foreach (string str in cominedIndexer)
                {
                    account.BankName = account.BankName + " " + pageline[Convert.ToInt16(str)];


                }
                account.BankName = account.BankName.Trim();
                _jumpToNext = allcontent[header.ContentID + 1];
                pageline = _jumpToNext.ContentValue.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).ToList();
                account.AccountNumber    = pageline[doc.AccountLineXIndex];
                // Bank is a combination space string so 

                // forgot to define the pattern for address on purpose so using indexer hard code
                account.Address = pageline[0] + " " + pageline[1] + " " + pageline[2];

                accounts.Add(account);
            }

            #region "Get Data inside flat file tables"
            List<DataIndexerPoint> allIndexers = GetIndexers(datas, doc, allContent);
            LineContent realContentData = null;
            string[] ledgerContent = null;
            AccountLedger ledgerData = null;
            List<AccountLedger> ledgerInformation = new List<AccountLedger>();
            foreach (DataIndexerPoint pointer in allIndexers)
            {
               for(int i = pointer.StartIndex; i < pointer.EndIndex; i++)
                {
                    ledgerData = new AccountLedger();
                    realContentData = allContent[i];
                    /* here i am using 0 , 1 , 2 , 3 , 4 but you can put this settings into Doc Template 
                    
                    ledgerContent = realContentData.ContentValue.Split(" ".ToCharArray());
                    ledgerData.Description = ledgerContent[0];
                    ledgerData.DEBITS = Convert.ToDecimal( ledgerContent[1]);
                    ledgerData.CREDITS = Convert.ToDecimal(ledgerContent[2]);
                    ledgerData.Date = ledgerContent[3];
                    ledgerData.Balance = Convert.ToDecimal( ledgerContent[4]);
                    ledgerInformation.Add(ledgerData); 
                    For this section you need specific settings for sub header and statements 
                    // distance based indexers.
                    
                 
                  */

                    Console.WriteLine(realContentData.ContentValue);
                }


            }
#endregion

            return accounts;

        }

         #endregion

        List<AccountInformation> ISingleFileLogicController.ReadFile( DocTemplate document)
        {
            StreamReader file = null;
            string line = String.Empty;
            int counter = 0;
           int _tableIndex = 0;
            string content = String.Empty;
            LineContent _linecontent = null;
            List<AccountInformation> accountinfos = null;
            try
            {

                    file = new System.IO.StreamReader(document.DocTemplateURL + "//" +  ConfigurationManager.AppSettings["templatePath"].ToString());
                    
                    while ((line = file.ReadLine()) != null) 
                    {
                          _linecontent = new LineContent();
                          _linecontent.ContentID = counter;
                          _linecontent.ContentValue = line;
                           if(line.Contains(document.DocTemplateStartToken))
                           {
                               _linecontent.MarkStartToken = document.DocTemplateStartToken;
                              _tableIndex = _tableIndex + 1;
                           }
                           else if(line.Contains(document.DocTemplateEndToken))
                           {
                              _linecontent.MarkEndToken = document.DocTemplateEndToken;

                           }
                           else
                           {
                                 _linecontent.MarkStartToken = "######";
                                 _linecontent.MarkEndToken = "######";


                           }
                          allContent.Add(_linecontent);
                         counter++;
                    }
                file.Close();

                accountinfos =  LoadLedgerAccountHeaderInformation(allContent, document);

            }
            catch (FileNotFoundException excpfile)
            {


            }

            catch(Exception e )
            {


            }
            finally
            {


            }

     
            return accountinfos;

        }

       
    }

   
}
